/**
 * Validates score to accept only numeric natural numbers.
 * @param {number} object a number for the score
 * @param {string} message a HTML tag for the error message
 * @returns {boolean} valid: false, invalid: true; used for on submit validation.
 */
function validateScore(object, message) {
    var scorePattern = /^[0-9]+$/;
    var requiredValue = object.value;
    message.style.display = "inline";

    // if the required field has any input return false else return true
    if (requiredValue.length != 0) {
        if (!scorePattern.test(object.value)) {
            message.innerHTML = "Score must be a numeric natural number!";
            object.style.borderColor = "red";
            return true;
        }
        else {
            message.innerHTML = "";
            object.style.borderColor = "black";
            return false;
        }
    }
    else {
        message.innerHTML = "All fields are mandatory!"; // puts the error message into the specified HTML tag
        object.style.borderColor = "red"; // changes the border color to red
        return true;
    }
}

/**
 * Validates form by going through each input element and checking their respective functions.
 * Assumes the form is valid in the first place. Then, if there are any invalid inputs, sets
 * valid to false and returns valid. If valid is false, the form will not be submitted.
 * @returns {boolean} valid
 */
function validateForm(element1, element2) {
    var valid = true;
    element1 = element1.toString();
    element2 = element2.toString();

    if (validateScore(document.getElementById(element1), document.getElementById('error0'))) {
        valid = false;
    }

    if (validateScore(document.getElementById(element2), document.getElementById('error1'))) {
        valid = false;
    }

    return valid;
}
